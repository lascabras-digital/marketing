# Las Cabras | Marketing Digital

Sitio web oficial de Las Cabras Marketing Digital.

## Deploy en GitHub Pages

1. Subí esta carpeta a un repositorio en GitHub
2. Andá a Settings > Pages
3. En "Source" elegí: Deploy from a branch > main > / (root)
4. GitHub te dará una URL tipo: `https://tuusuario.github.io/lascabras`

## Conectar dominio propio (lascabras.marketing)

1. En GitHub Pages > Custom domain, escribí: `lascabras.marketing`
2. En tu registrador de dominio (Namecheap / GoDaddy), agregá estos registros DNS:
   - Tipo A → 185.199.108.153
   - Tipo A → 185.199.109.153
   - Tipo A → 185.199.110.153
   - Tipo A → 185.199.111.153
   - Tipo CNAME → www → tuusuario.github.io
3. Esperá 24-48hs para que propague

## Personalización rápida

- **Logo**: reemplazá `logo-cabra.png` y `logo-texto.png` con tus archivos
- **Colores**: editá las variables CSS en `:root` al inicio del `<head>`
- **Contenido**: buscá los textos entre las etiquetas HTML y reemplazalos
- **Videos YouTube**: en la sección `#videos`, reemplazá el placeholder con tus iframes reales

## Próximo paso: conectar formularios

Para que el formulario de contacto funcione de verdad, registrate gratis en:
- **Formspree** (formspree.io) — reemplazá el `onclick="sendForm()"` con action de Formspree
- **MailerLite** — conectá el formulario de newsletter con tu cuenta

